<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./estilos.css">
    <title>quiz</title>
</head>

<body>
    <header>
        <h1>¿Qué plantas se llevan mejor con vos?</h1>
    </header>
    <nav>
        <a href="index.php" class="publico">Suscribite</a>
        <a href="login.php" class="privado">Login</a>
        <a href="mostrarContenido.php" class="privado">Panel de administrador</a>
        <a href="finalizados.php" class="privado">Finalizados</a>
        <a href="salir.php" class="privado">Salir</a>
    </nav>